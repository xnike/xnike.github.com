module.exports = function(grunt) {

  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    qunit: {
      all: ['js/*.html']
    }
  });

  grunt.loadNpmTasks('grunt-contrib-qunit');
  
  grunt.registerTask('test', ['qunit']);
  grunt.registerTask('default', ['test', 'build-contrib']);
};