QUnit.test('getSum(1, 2)', function(assert) {
	var result = getSum(1, 2);
	assert.equal(result, 1 + 2);
});

QUnit.test('getSum(5, 4)', function(assert) {
	var result = getSum(5, 4);
	assert.equal(result, 5 + 4);
});