function getSum(a, b) {
	return a + b;
}